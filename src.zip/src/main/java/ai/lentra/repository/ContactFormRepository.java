package ai.lentra.repository;

import ai.lentra.modal.ContactForm;
import ai.lentra.modal.lookups.SimCardType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactFormRepository extends JpaRepository<ContactForm, Long> {

    ContactForm findByApplicantId(Long applicantId);
}
