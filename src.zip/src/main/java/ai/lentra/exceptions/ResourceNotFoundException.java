package ai.lentra.exceptions;

public class ResourceNotFoundException extends Exception {
    public ResourceNotFoundException(String simCardTypeNotFound) {
        super(simCardTypeNotFound);
    }
}
