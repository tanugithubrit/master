package ai.lentra.modal;

import ai.lentra.modal.lookups.SimCardType;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Data
public class ContactForm {

    @Id
    @Column(name = "applicant_id", nullable = false)
    private long applicantId;
    @NotNull(message = "Mobile number should not be null")
    @Pattern(regexp = "^\\d{10,13}$",message = "Mobile number should contain 10 to 13 digits only")
    private String mobileNumber;

    @NotNull(message = "Personal email should not be null")
    @Pattern(regexp = "^[a-zA-Z0-9._%+-]{1,64}@[a-zA-Z0-9.-]{1,63}\\.[a-zA-Z]{2,}$",message = "Email must be well formed")
    private String personalEmail;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "sim_card_type")
    private SimCardType simType;

    private boolean mobileNumberVerified;

    @Pattern(regexp = "^\\d{10,13}$",message = "Phone number should contain 10 to 13 digits only")
    private String phoneNumber;

    private boolean phoneNumberVerified;
    private boolean personalEmailVerified;
    private boolean domainCheck;
    private boolean registeredWithBank;


}