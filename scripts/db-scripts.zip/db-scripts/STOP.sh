#!/bin/bash
set -e

sudo docker-compose down -v 
