#!/bin/bash
set -e

sudo docker-compose --compatibility up --build   
